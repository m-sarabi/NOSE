This is my datapack for the N.O.P.E (Not Ordinary Playing Experience) server. A hardcore server with only two lives.

Upon death player is sent to hell, a hard superflat server with limited resources. There they have to complete certain tasks to revive and play in normal world again.